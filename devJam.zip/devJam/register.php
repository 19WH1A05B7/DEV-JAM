<!DOCTYPE html>
<html>
    <head>
        <title>Register</title>
    </head>
    <body>
        <div clss="container">
            <form class="login-email">
                <div class="input-group">
                    <input type="text" placeholder="username" name="username" required>
                </div>
                <div class="input-group">
                    <input type="email" placeholder="Email" required>
                </div>
                <div class="input-group">
                    <input type="password" placeholder="Password" required>
                </div>
                <div class="input-group">
                    <input type="password" placeholder="Confirm Password" required>
                </div>
                <div class="input-group">
                    <button class="btn">Login</button>
                </div>
                <p class="login-register-text">Have an account? <a href="index.php">Login Here</a></p>
    </body>
</html>

