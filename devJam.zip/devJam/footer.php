<footer class="w3-container w3-theme w3-center" style="padding:1px">
      <p>Developed by: Tiny Coders</p>
       &copy; 2021
 
</footer>
