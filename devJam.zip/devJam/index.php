
<!DOCTYPE html>
<html>
<title>Placement Portal</title>
<!--<link rel = "icon" href = "images/logo.jpg" type = "image/x-icon">-->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<!-- Navbar (sit on top)
<div class="w3-top w3-bar w3-teal">
    <img class="w3-image" src="images/logo.jpg" alt="Architecture" width="70" height="10">
    <div class="w3-center w3-xxlarge">BVRIT HYDERABAD College of Engineering for Women </div>
    <a class="w3-bar-item w3-button w3-right" onclick="document.getElementById('id01').style.display='block'">Login</a>
   
</div> 
<header class=" w3-teal w3-wide" style="max-width:1500px;" id="home">
   
  <div class="">
      <img class="w3-image" src="images/logo.jpg" alt="BVRITH" width="100" height="40">
      <span class="w3-xlarge">BVRIT HYDERABAD College of Engineering for Women</span>
       
      <span class="w3-right"><a class="w3-button" onclick="document.getElementById('id01').style.display='block'">Login</a></span>
      
  </div> 
     
</header> -->
<!-- <h1 class="w3-xxlarge w3-text-white"><span class="w3-padding w3-black w3-opacity-min"><b>KM</b></span> <span class="w3-hide-small w3-text-light-grey">Valuations</span></h1> -->
   
<body class="w3-container " style="background-image: url('images/bg1.png');">

    <div class="w3-quarter w3-container">
        <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <br><br>
        <br>
      
    </div>
<!-- <img class="w3-image w3-transparent w3-hoverable " src="images/bg3.png" alt="BVRITH" width="1500" height="600">  -->
    <div class="w3-quarter w3-container">
        <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <br>
        <br>
    </div>
       <br> <br>
   <div class="w3-half w3-container w3-mobile w3-card-4 w3-animate-zoom"  style="max-width:400px; max-height:500px;">
       
      <div class="w3-center"><br>
          <img src="images/logo.jpg" alt="Avatar" style="width:20%" class="w3-circle w3-margin-top">
          <h2 class=""><i class="w3-italic"><b>Placement Portal</b></i></h2>
      </div>
       
        <form class="w3-container" action="login.php" method="post">
        <div class="w3-section">
          <label><b>Login Email</b></label>
          <input class="w3-input w3-border w3-margin-bottom" type="email" placeholder="Enter Email" name="loginEmail" required>
          <label><b>Password</b></label>
          <input class="w3-input w3-border" type="password" placeholder="Enter Password" name="pwd" required>
          <button class="w3-button w3-block w3-green w3-section w3-padding" type="submit">Login</button>
          <input class="w3-check w3-margin-top" type="checkbox" checked="checked"> Remember me
          <br>
          <a href="forget_pwd.php"><b>Forget Password?<b></a>
        </div>
      </form>      
    </div>
       
       


</body>

</html>


